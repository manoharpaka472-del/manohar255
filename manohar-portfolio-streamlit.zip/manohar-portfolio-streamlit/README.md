# Paka Manohar – Portfolio (Streamlit)

An animated, 3D mechanical-engineering portfolio served through Streamlit.

## Files
- `app.py` – Streamlit entry point
- `builder.py` – inserts your product photos into the page
- `portfolio.html` – the full website (3D models, animations)
- `assets/products/` – put your real product photos here (see the README inside)
- `.streamlit/config.toml` – dark theme
- `requirements.txt`

## Deploy on Streamlit Community Cloud (free, no login for visitors)
1. Create a GitHub repository and upload everything in this folder.
2. Go to https://share.streamlit.io and sign in with GitHub.
3. Click **Create app**, choose your repository and branch, and set the main file to `app.py`.
4. Click **Deploy**. You get a public `*.streamlit.app` link to share.

Free apps go to sleep when nobody visits; the first visitor after a while may see a short "wake up" screen.

## Run locally
```
pip install -r requirements.txt
streamlit run app.py
```

## Update photos
Add or replace images in `assets/products/`, commit to GitHub, and the app redeploys automatically.
