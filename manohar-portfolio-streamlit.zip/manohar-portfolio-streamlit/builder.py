"""Builds the portfolio HTML, adding real project photos when they exist."""
import base64
import io
import json
import mimetypes
from pathlib import Path

# template key -> file name (without extension) inside assets/products/
PHOTO_FILES = {
    "dryer": "cloth_dryer",
    "cool": "cooling_enclosure",
    "light": "street_light",
    "soil": "soil_moisture_alarm",
    "meter": "energy_meter",
    "solar": "solar_tracker",
    "app": "studentapppro",
}
EXTENSIONS = (".jpg", ".jpeg", ".png", ".webp")


def _photo_source(root: Path, name: str) -> str:
    folder = root / "assets" / "products"
    for ext in EXTENSIONS:
        f = folder / (name + ext)
        if f.exists():
            try:
                from PIL import Image

                im = Image.open(f).convert("RGB")
                im.thumbnail((1100, 1100))
                buf = io.BytesIO()
                im.save(buf, "JPEG", quality=82, optimize=True)
                return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()
            except Exception:
                mime = mimetypes.guess_type(f.name)[0] or "image/jpeg"
                return f"data:{mime};base64," + base64.b64encode(f.read_bytes()).decode()
    urls = folder / "image_urls.json"
    if urls.exists():
        try:
            return json.loads(urls.read_text(encoding="utf-8")).get(name, "").strip()
        except Exception:
            return ""
    return ""


def build_html(root: Path) -> str:
    html = (root / "portfolio.html").read_text(encoding="utf-8")
    for key, name in PHOTO_FILES.items():
        src = _photo_source(root, name)
        tag = ""
        if src:
            tag = f'<img class="rw" alt="" src="{src}" referrerpolicy="no-referrer" loading="lazy">'
            if key != "app":
                tag += '<button class="sw3" type="button">View 3D</button>'
        html = html.replace("{{PHOTO_%s}}" % key, tag)
    return html
